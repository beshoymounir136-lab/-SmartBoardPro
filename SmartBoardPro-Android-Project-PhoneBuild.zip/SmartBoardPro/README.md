# Smart Board Pro (Android)

Android Studio project for a touch/stylus whiteboard. Includes pen, marker/highlighter, eraser, color palette, undo/redo, clear, and PNG export.

## Build APK
1. Open this folder in Android Studio (Giraffe or newer).
2. Let Gradle sync and install Android SDK Platform 35 if prompted.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

Package: `com.smartboardpro.app`
