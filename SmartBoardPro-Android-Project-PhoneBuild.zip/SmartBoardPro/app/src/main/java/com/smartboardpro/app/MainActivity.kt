package com.smartboardpro.app

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.view.*
import android.widget.*
import android.content.ContentValues
import android.provider.MediaStore
import android.graphics.drawable.GradientDrawable
import kotlin.math.max

class MainActivity : Activity() {
    private lateinit var board: BoardView
    private var selectedColor = Color.BLACK
    private var selectedTool = "قلم"
    private var selectedWidth = 7f
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(245,247,251)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(12,8,12,8) }
        val title = TextView(this).apply { text = "Smart Board Pro"; textSize = 20f; setTextColor(Color.rgb(20,30,50)); typeface = Typeface.DEFAULT_BOLD }
        header.addView(title, LinearLayout.LayoutParams(0, dp(48), 1f))
        val undo = button("↶") { board.undo() }; header.addView(undo)
        val redo = button("↷") { board.redo() }; header.addView(redo)
        val clear = button("مسح") { board.clear() }; header.addView(clear)
        val save = button("حفظ") { saveBoard() }; header.addView(save)
        root.addView(header)

        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(6,4,6,8) }
        listOf("قلم", "ماركر", "هايلايتر", "ممحاة", "خط", "دائرة", "مستطيل").forEach { name ->
            tools.addView(button(name) {
                selectedTool = name
                selectedWidth = when(name) { "ماركر" -> 18f; "هايلايتر" -> 25f; "ممحاة" -> 34f; else -> 7f }
                status.text = "الأداة: $name"
            })
        }
        root.addView(tools)
        val palette = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(4,0,4,8) }
        val colors = listOf(Color.BLACK, Color.RED, Color.BLUE, Color.GREEN, Color.MAGENTA, Color.CYAN, Color.YELLOW, Color.WHITE, Color.DKGRAY)
        colors.forEach { color ->
            val swatch = View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color); setStroke(dp(1), Color.LTGRAY) }
                setOnClickListener { selectedColor = color; status.text = "تم اختيار اللون" }
            }
            palette.addView(swatch, LinearLayout.LayoutParams(dp(30), dp(30)).apply { setMargins(dp(5),0,dp(5),0) })
        }
        root.addView(palette)
        board = BoardView(this)
        root.addView(board, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(dp(8),0,dp(8),dp(6)) })
        status = TextView(this).apply { text = "الأداة: قلم  •  اسحب بإصبعك أو بالقلم للكتابة"; textSize = 12f; setTextColor(Color.DKGRAY); gravity = Gravity.CENTER; setPadding(4,4,4,8) }
        root.addView(status)
        setContentView(root)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 11f; isAllCaps = false; minWidth = 0; minimumWidth = 0; setPadding(dp(7),0,dp(7),0)
        setOnClickListener { action() }
    }

    private fun saveBoard() {
        try {
            val bmp = board.exportBitmap()
            val values = ContentValues().apply { put(MediaStore.Images.Media.DISPLAY_NAME, "SmartBoard_${System.currentTimeMillis()}.png"); put(MediaStore.Images.Media.MIME_TYPE, "image/png"); put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SmartBoardPro") }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: throw Exception("storage")
            contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            Toast.makeText(this, "تم حفظ السبورة في الصور", Toast.LENGTH_LONG).show()
        } catch (e: Exception) { Toast.makeText(this, "تعذر حفظ الصورة", Toast.LENGTH_LONG).show() }
    }

    inner class BoardView(context: android.content.Context) : View(context) {
        private data class Stroke(val path: Path, val color: Int, val width: Float, val style: Paint.Style)
        private val strokes = mutableListOf<Stroke>()
        private val undone = mutableListOf<Stroke>()
        private var current: Path? = null
        private var currentColor = Color.BLACK
        private var currentWidth = 7f
        private var currentStyle = Paint.Style.STROKE
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        private val paper = Paint().apply { color = Color.WHITE }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas); canvas.drawColor(Color.WHITE)
            strokes.forEach { drawStroke(canvas, it) }
            current?.let { drawStroke(canvas, Stroke(it,currentColor,currentWidth,currentStyle)) }
        }
        private fun drawStroke(canvas: Canvas, s: Stroke) { paint.color=s.color; paint.strokeWidth=s.width; paint.style=s.style; if (s.color==Color.WHITE && s.width>20f) paint.blendMode=BlendMode.CLEAR else paint.blendMode=BlendMode.SRC_OVER; canvas.drawPath(s.path,paint); paint.blendMode=BlendMode.SRC_OVER }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            when(e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    currentColor = if(selectedTool=="ممحاة") Color.WHITE else selectedColor
                    if(selectedTool=="هايلايتر") currentColor = (selectedColor and 0x00FFFFFF) or 0x55000000
                    currentWidth = if(selectedTool=="ممحاة") 36f else selectedWidth
                    currentStyle = Paint.Style.STROKE
                    current = Path().apply { moveTo(e.x,e.y) }; parent?.requestDisallowInterceptTouchEvent(true); invalidate(); return true
                }
                MotionEvent.ACTION_MOVE -> { current?.lineTo(e.x,e.y); invalidate(); return true }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { current?.let { strokes.add(Stroke(it,currentColor,currentWidth,currentStyle)); undone.clear() }; current=null; invalidate(); return true }
            }
            return true
        }
        fun undo() { if(strokes.isNotEmpty()) undone.add(strokes.removeAt(strokes.lastIndex)); invalidate() }
        fun redo() { if(undone.isNotEmpty()) strokes.add(undone.removeAt(undone.lastIndex)); invalidate() }
        fun clear() { strokes.clear(); undone.clear(); invalidate() }
        fun exportBitmap(): Bitmap { val b=Bitmap.createBitmap(max(width,1),max(height,1),Bitmap.Config.ARGB_8888); val c=Canvas(b); c.drawColor(Color.WHITE); strokes.forEach { drawStroke(c,it) }; return b }
    }
}
